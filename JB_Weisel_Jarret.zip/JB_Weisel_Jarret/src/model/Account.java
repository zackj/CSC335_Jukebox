package model;

/**
 * Manages a student's account information and song statistics
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

public class Account {
	private String userId;
	private int songsPlayedToday = 0;
	private int secondsPlayed = 0;
	
	public Account(String id) {
		userId = id;
	}
	
	
	/**
	 * @return the user id for this account instance
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * it's a new day, therefore we need to reset the number of songs played today.
	 */
	public void newDay() {
		songsPlayedToday = 0;
	}
	
	/**
	 * increase the songs played today counter by one.
	 */
	public void songPlayedToday() {
		songsPlayedToday++;
	}
	
	/**
	 * @return the number of songs played today
	 */
	public int getSongsPlayedToday() {
		return songsPlayedToday;
	}
	
	/**
	 * add the number of seconds passed to the total number of seconds.
	 * @param seconds
	 */
	public void addToSecondsPlayed(int seconds) {
		secondsPlayed += seconds;
	}
	
	/**
	 * @return seconds counted up so far.
	 */
	public int getSecondsPlayed() {
		return secondsPlayed;
	}
	
	/**
	 * check if the user is allowed to play a song.
	 * @return
	 */
	public boolean canPlayASongNow() {
		return (songsPlayedToday < 2 && secondsPlayed < 1500*60);
	}
}