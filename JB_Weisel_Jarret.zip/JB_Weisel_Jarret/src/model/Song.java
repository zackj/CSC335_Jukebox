package model;

/**
 * Manages song information and play count for the specific song.
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

public class Song implements Comparable<Song>{

	private int songLength;
	private int todayPlayCount = 0;
	private String songName;
	private String songArtist;
	private String fileName;
	
	
	public Song(String name, String artist, String fName, int length){
		songName = name;
		songLength = length;
		songArtist = artist;
		fileName = fName;
	}

	
	/**
	 * Provide access to the fileName
	 * @return
	 */
	public String getFileName(){
		return fileName;
	}
	
	/**
	* Provide access to the length of a song
	* 
	* @return the song length, in seconds
	*/
	public int getLength() {
		return songLength;
	}
	
	/**
	 * Provide a way to get the long name (artist space song)
	 * @return the long format song name
	 */
	private String getLongName(){
		return songArtist + " " + songName;
	}
	
	/**
	 * Provide access to the song name
	 * @return
	 */
	public String getName(){
		return songName;
	}
	
	/**
	 * Provide way to increment play count
	 */
	public void incrementPlayCount(){
		todayPlayCount++;
	}
	
	/**
	 * Provide way to zero the play count
	 */
	public void newDay(){
		todayPlayCount = 0;
	}
	
	public boolean canBePlayed(){
		return (todayPlayCount < 5);
	}
	
	/**
	 * Required for comparable
	 */
	public int compareTo(Song o) {
		return this.getLongName().compareTo(o.getLongName());
	}


	
}
