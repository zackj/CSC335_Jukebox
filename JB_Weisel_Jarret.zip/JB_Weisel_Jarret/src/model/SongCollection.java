package model;

/**
 * Holds a collection of Songs objects. Manages unique songs only. Includes song lookups and resetting date information for songs in the collection.
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

import java.util.ArrayList;
import javax.swing.event.ListDataListener;

public class SongCollection implements javax.swing.ListModel{

	private ArrayList<Song> songs = new ArrayList<Song>();

	public SongCollection(){
		this.addSong(new Song("Determined Tumbao", "Freeplay", "DeterminedTumbao.mp3", 20));
		this.addSong(new Song("Swing Cheese", "Freeplay", "SwingCheese.mp3", 15));
		this.addSong(new Song("Tada", "Microsoft", "tada.wav", 2));
		this.addSong(new Song("Spam Song", "Monty Python", "spam_song.au", 29));
		this.addSong(new Song("Bottle Open", "Sun Microsystems", "bottle-open.wav", 1));

	}

	/**
	 * This function should be called at midnight every day
	 * The result is that it sets the song count to 0 for every song.
	 */
	public void newDay(){
		for (Song s : songs)
			s.newDay();
	}

	/**
	 * Add a song to the collection.
	 * @param song
	 */
	public void addSong(Song song) {
		Boolean songExists = false;

		for (Song s : songs)
			if (song.getFileName().compareTo(s.getFileName()) == 0) {
				songExists = true;
			}

		if (!songExists)
			songs.add(song);
	}
	
	/**
	 * look up a song by its name.
	 * @param Name
	 * @return the song object corresponding to that name. If it is not in the collection, it returns null.
	 */
	public Song getSongByName(String Name) {
		for (Song s : songs)
			if (s.getName().compareTo(Name) == 0)
				return s;
		return null;
	}

	/**
	 * return the number of songs in the collection
	 */
	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return songs.size();
	}
	
	/**
	 * lookup a song name at a specific index
	 * 
	 */

	@Override
	public String getElementAt(int index) {
		// TODO Auto-generated method stub
		return songs.get(index).getName();
	}
	
	@Override
	public void addListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub

	}
}


