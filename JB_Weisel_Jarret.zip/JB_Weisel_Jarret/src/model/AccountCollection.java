package model;

import java.util.ArrayList;

/**
 * Holds a collection of Account objects. Manages unique accounts only. Includes account lookups and resetting date information for accounts in the collection.
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

public class AccountCollection {
	
	ArrayList<Account> accounts = new ArrayList<Account>();
	
	/**
	 * Add an account to the collection. Check that it does not already exist.
	 * @param account
	 */
	public void addAccount(Account account) {
		Boolean accountExists = false;
		
		for (Account a : accounts)
			if (account.getUserId().compareTo(a.getUserId()) == 0) {
					accountExists = true;
			}
		
		if (!accountExists)
			accounts.add(account);
	}
	
	/**
	 * reset the day for each account in the collection
	 */
	public void newDay(){
		for (Account a : accounts)
			a.newDay();
	}
	
	/**
	 * lookup an account by its id.
	 * @param id
	 * @return
	 */
	public Account getAccountById(String id) {
		for (Account a : accounts)
			if (a.getUserId().compareTo(id) == 0)
				return a;
		return null;
	}
}
