package model;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Manage a list of Song objects on a FIFO basis.
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

public class PlayList {

	private Queue<Song> songList = new LinkedList<Song>();
	
	/**
	 * add a song to the list.
	 * @param song
	 */
	public void add(Song song){
		songList.add(song);
	}
	
	/**
	 * remove and return a song from the lowest index of the list
	 * @return
	 */
	public Song remove(){
		return songList.remove();
	}
	
	/**
	 * @return the number of items in the play list.
	 */
	public int size() {
		return songList.size();
	}
}