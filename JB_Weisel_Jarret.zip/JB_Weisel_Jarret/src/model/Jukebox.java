package model;

import java.util.GregorianCalendar;

import songplayer.AudioFilePlayer;

/**
 * Jukebox ties all of the other model classes together. Manages the playlist, songs, accounts, audio and date information.
 * 
 * @author Max Weisel, Zack Jarret
 *
 */

public class Jukebox {
	
	private PlayList songQueue;
	private SongCollection songCollection;
	private AccountCollection acctCollection;
	private Account currentAccount = null;
	private GregorianCalendar currentDate;
	private GregorianCalendar tmpDate;
	private Boolean isCurrentlyPlaying = false;
	private AudioFilePlayer audioPlayer;
	
	public Jukebox() {
		songQueue = new PlayList();
		songCollection = new SongCollection();
		acctCollection = new AccountCollection();
		currentDate = new GregorianCalendar();
	}
	
	/**
	 * set the current account based on the account ID pulled off of the card swiped.
	 * @param acctID
	 */
	public void swipeReceived(String acctID){
		currentAccount = acctCollection.getAccountById(acctID);
	}

	/**
	 * clear out the current account upon logging out.
	 */
	public void logOut(){
		currentAccount = null;
	}
	
	/**
	 * Play the next song in the queue. If there are no more songs left, stop the queue.
	 */
	private void playAudioForNextSong() {
		//Thread.sleep(1000); // Exception handling?
		if (songQueue.size() > 0) {
			Song nextSong = songQueue.remove();
			audioPlayer = new AudioFilePlayer(nextSong.getFileName());
			audioPlayer.addEndOfSongListener((songplayer.EndOfSongListener) new EndOfTheSongListener());
			audioPlayer.play();
			isCurrentlyPlaying = true;
		} else {
			isCurrentlyPlaying = false;
		}
	}
	
	/**
	 * Listener used to queue up the next song in the playlist.
	 *
	 */
	private class EndOfTheSongListener implements EndOfSongListener {

		public void songFinishedPlaying(String fileName) {
			playAudioForNextSong();
		}
		
	}
	
	/**
	 * Adds a song to the queue. If the jukebox is not playing (no songs in the playlist) start the queue.
	 * @param string
	 */

	public void playSong(String string) {
		Song song = songCollection.getSongByName(string);
		
		tmpDate = new GregorianCalendar();
		
		if ((currentDate.getTimeInMillis() - tmpDate.getTimeInMillis()) > 60*60*24*1000){
			currentDate.setTimeInMillis(currentDate.getTimeInMillis() + 60*60*24*1000);
			songCollection.newDay();
			acctCollection.newDay();
		}
		
		if (song.canBePlayed() && currentAccount.canPlayASongNow()){
			songQueue.add(song);
			if (!isCurrentlyPlaying)
				playAudioForNextSong();
			song.incrementPlayCount();
			currentAccount.songPlayedToday();
			currentAccount.addToSecondsPlayed(song.getLength());
		} else {
			System.out.println("You suck.  Can't play music right now.");
		}
	}
		
}
