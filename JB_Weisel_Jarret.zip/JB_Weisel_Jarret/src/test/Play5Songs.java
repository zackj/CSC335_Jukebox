package test;

import model.Jukebox;

public class Play5Songs {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Jukebox jukebox = new Jukebox();
		
		
		jukebox.swipeReceived("Chris");
		//Someday there will be a chooser.
		//Someday there will be cheese for all the hungry children.
		
		// Add the following songs to the queue.
		jukebox.playSong("Determined Tumbao");
		jukebox.playSong("Swing Cheese");
		jukebox.playSong("Tada");
		jukebox.playSong("Spam Song");
		jukebox.playSong("Bottle Open");
	}

}
