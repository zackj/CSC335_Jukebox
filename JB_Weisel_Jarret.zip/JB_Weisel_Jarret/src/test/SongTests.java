package test;

import org.junit.Before;
import org.junit.Test;

import model.Song;



public class SongTests {
	private Song song;

	@Before
	public void setUp() {
		song = new Song("Determined Tumbao", "Freeplay", "DeterminedTumbao.mp3", 30);
	}


	@Test
	public void testSongDataGetters(){

		org.junit.Assert.assertTrue(song.getFileName().compareTo("DeterminedTumbao.mp3")==0);
		//org.junit.Assert.assertTrue(song.getLongSongName().compareTo("Freeplay Determined Tumbao")==0);
		org.junit.Assert.assertTrue(song.getName().compareTo("Determined Tumbao")==0);
		org.junit.Assert.assertEquals(30, song.getLength());

	}

	@Test
	public void testSongIncrementAndCanBePlayed(){
		song.newDay();
		song.incrementPlayCount();
		org.junit.Assert.assertTrue(song.canBePlayed());
		song.incrementPlayCount();
		org.junit.Assert.assertTrue(song.canBePlayed());
		song.incrementPlayCount();
		org.junit.Assert.assertTrue(song.canBePlayed());
		song.incrementPlayCount();
		org.junit.Assert.assertTrue(song.canBePlayed());
		song.incrementPlayCount();
		//Now that the song has played 5 times, it should not be playable anymore
		org.junit.Assert.assertFalse(song.canBePlayed());

		//reset the playcount and it should be playable again
		song.newDay();
		org.junit.Assert.assertTrue(song.canBePlayed());
	}

	/**
	 * Tests the compareTo function required for implementing comparable
	 * Implicitly tests song.getLongName() too.
	 */
	@Test
	public void songCompareTest(){
		Song laterSong = new Song("Tada", "Microsoft", "tada.wav", 30);
		Song beforeSong = new Song("Broken Record", "Freeplay", "blahblah", 30);
		Song sameSong = new Song("Determined Tumbao", "Freeplay", "DeterminedTumbao.mp3", 30);

		org.junit.Assert.assertTrue(song.compareTo(laterSong) < 0);
		org.junit.Assert.assertTrue(song.compareTo(beforeSong) > 0);
		org.junit.Assert.assertTrue(song.compareTo(sameSong) == 0);

	}

}
