package test;

import static org.junit.Assert.*;

import org.junit.Test;

import model.Account;

public class AccountTest {
	@Test
	public void accountCreationTest() {
		Account anAccount = new Account("Chris");
		assertTrue(anAccount.getUserId().compareTo("Chris") == 0);
	}
	
	@Test
	public void songsPlayedTodayTest() {
		Account anAccount = new Account("Chase");
		assertTrue(anAccount.getSongsPlayedToday() == 0);
		
		anAccount.songPlayedToday();
		assertTrue(anAccount.getSongsPlayedToday() == 1);

		anAccount.songPlayedToday();
		assertTrue(anAccount.getSongsPlayedToday() == 2);
		
		anAccount.newDay();
		assertTrue(anAccount.getSongsPlayedToday() == 0);
	}
	
	@Test
	public void minutesPlayedTest() {
		Account anAccount = new Account("Carson");
		assertTrue(anAccount.getSecondsPlayed() == 0);
		
		anAccount.addToSecondsPlayed(5*60);
		assertTrue(anAccount.getSecondsPlayed() == 5*60);
		
		anAccount.addToSecondsPlayed(300*60);
		assertTrue(anAccount.getSecondsPlayed() == 305*60);
	}
	
	@Test
	public void canPlayASongTest() {
		Account anAccount = new Account("Casey");
		assertTrue(anAccount.getSongsPlayedToday() == 0);
		
		assertTrue(anAccount.canPlayASongNow());
		
		anAccount.songPlayedToday();
		anAccount.songPlayedToday();
		
		assertFalse(anAccount.canPlayASongNow());
		
		anAccount.newDay();
		
		assertTrue(anAccount.canPlayASongNow());
		
		anAccount.addToSecondsPlayed(1499*60);
		assertTrue(anAccount.canPlayASongNow());
		
		anAccount.addToSecondsPlayed(3*60);
		assertFalse(anAccount.canPlayASongNow());
	}
}
