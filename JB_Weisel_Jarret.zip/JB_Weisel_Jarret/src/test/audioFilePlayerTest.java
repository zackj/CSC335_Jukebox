package test;


import songplayer.AudioFilePlayer;

import org.junit.Before;

public class audioFilePlayerTest {

	@Before
	public void setUp() throws Exception {
		String fPath = "/home/zjarrett/workspace/JukeboxProject/songfiles/bottle-open.wav";
		AudioFilePlayer a = new AudioFilePlayer(fPath);
	}

}
