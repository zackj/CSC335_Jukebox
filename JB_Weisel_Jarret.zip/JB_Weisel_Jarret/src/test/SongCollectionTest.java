package test;


import model.SongCollection;
import model.Song;

import org.junit.Before;
import org.junit.Test;

public class SongCollectionTest {

	private SongCollection songColl;

	@Before
	public void setUp() {
		songColl = new SongCollection();
	}

	@Test
	public void getSongByNameTest(){
		Song bottleSong = songColl.getSongByName("Bottle Open");
		org.junit.Assert.assertTrue(bottleSong.getName().compareTo("Bottle Open") == 0);
		org.junit.Assert.assertTrue(bottleSong.getFileName().compareTo("bottle-open.wav") == 0);

	}

	@Test
	public void getSongCollectionSizeTest(){
		org.junit.Assert.assertEquals(5, songColl.getSize());
	}

	@Test
	public void getElementAtTest(){
		//, "Freeplay", "DeterminedTumbao.mp3", 30
		org.junit.Assert.assertTrue(songColl.getElementAt(4).compareTo("Bottle Open")==0);
	}
	
	@Test
	public void newDayTest(){
		//Set the play count up on various songs, then ask those songs if they can be played.
		songColl.getSongByName("Bottle Open");
		Song aSong = songColl.getSongByName("Determined Tumbao");
		Song bSong = songColl.getSongByName("Swing Cheese");
		Song cSong = songColl.getSongByName("Tada");
		Song dSong = songColl.getSongByName("Spam Song");
		Song eSong = songColl.getSongByName("Bottle Open");
		
		int i;
		
		for (i=0; i<5; i++){
			aSong.incrementPlayCount();
			bSong.incrementPlayCount();
			cSong.incrementPlayCount();
			dSong.incrementPlayCount();
			eSong.incrementPlayCount();
		}
		
		//Check that the songs can't be played.
		org.junit.Assert.assertFalse(aSong.canBePlayed());
		org.junit.Assert.assertFalse(bSong.canBePlayed());
		org.junit.Assert.assertFalse(cSong.canBePlayed());
		org.junit.Assert.assertFalse(dSong.canBePlayed());
		org.junit.Assert.assertFalse(eSong.canBePlayed());
		
		songColl.newDay();
		org.junit.Assert.assertTrue(aSong.canBePlayed());
		org.junit.Assert.assertTrue(bSong.canBePlayed());
		org.junit.Assert.assertTrue(cSong.canBePlayed());
		org.junit.Assert.assertTrue(dSong.canBePlayed());
		org.junit.Assert.assertTrue(eSong.canBePlayed());

	}

}
